//
//  Commen.m
//  YYApp
//
//  Created by King.Com on 2018/10/10.
//  Copyright © 2018年 King.Com. All rights reserved.
//

#import "Commen.h"

#import "GetCurrentDeviceModel.h"

@implementation Commen

+ (NSString *)getLocale
{
    NSInteger lang = [CLanguageUtil getCurrentLanguage];
    NSString *locale;
    if (lang == 0) {
        locale = @"en_US";
    } else if (lang == 1){
        locale = @"zh_CN";
    }else  {
        locale = @"my_MM";
    }
    return locale;
}

#pragma mark - 获取手机唯一标示（手机名称、唯一标示符等）
+ (NSMutableString *)getMobilephoneUniqueLogo
{
    //设备名#系统版本#唯一标示
    NSMutableString *mutStr = [[NSMutableString alloc] initWithString:@""];
   
    //可在此处添加要拼接的全局字段 eg:语言 国家 加密id ...
    
    if ([self getLocale]) {
        [mutStr appendFormat:@"&locale=%@", [self getLocale]];
    }
    
    NSString* deviceName = [GetCurrentDeviceModel GetCurrentDeviceModel]; //获得设备型号
    NSString *uuid = [[[UIDevice currentDevice] identifierForVendor] UUIDString]; //获取设备uuid
   
    if (deviceName) {
        [mutStr appendFormat:@"&vsid=%@", deviceName];
    }
  
    
    //手机系统版本
    NSString* phoneVersion = [[UIDevice currentDevice] systemVersion];
    if (phoneVersion) {
        [mutStr appendFormat:@",%@", phoneVersion];
    }
    if (uuid) {
        [mutStr appendFormat:@",%@", uuid];
    }else {
        if ([UserDefaults objectForKey:@"date"]) {
            [mutStr appendFormat:@",%@", [UserDefaults objectForKey:@"date"]];
        }else {
            NSDate *senddate = [NSDate date];
            NSDateFormatter *dateformatter = [[NSDateFormatter alloc] init];
            [dateformatter setDateFormat:@"YYYY-MM-dd HH:mm:ss"];
            NSString *date1 = [dateformatter stringFromDate:senddate];
            [UserDefaults setObject:date1 forKey:@"date"];
            [mutStr appendFormat:@",%@", date1];
        }
        
    }
    return mutStr;
}
@end
