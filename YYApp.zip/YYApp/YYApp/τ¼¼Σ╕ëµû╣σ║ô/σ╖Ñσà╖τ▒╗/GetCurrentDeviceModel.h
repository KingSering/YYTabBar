//
//  GetCurrentDeviceModel.h
//  e65_ios
//
//  Created by King.Com on 2017/3/16.
//  Copyright © 2017年 King.Com. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface GetCurrentDeviceModel : NSObject

+ (NSString *)GetCurrentDeviceModel;

@end
