//
//  Commen.h
//  YYApp
//
//  Created by King.Com on 2018/10/10.
//  Copyright © 2018年 King.Com. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Commen : NSObject


#pragma mark - 获取当前语言
+ (NSString *_Nullable)getLocale;

#pragma mark - 获取手机唯一标示
+ (NSMutableString *_Nullable)getMobilephoneUniqueLogo;
@end
