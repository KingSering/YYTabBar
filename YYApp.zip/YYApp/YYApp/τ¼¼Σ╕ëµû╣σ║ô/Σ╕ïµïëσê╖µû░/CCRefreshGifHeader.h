//
//  CCRefreshGifHeader.h
//  ask_dear商家
//
//  Created by xiezhaolin on 16/6/6.
//  Copyright © 2016年 King.Com. All rights reserved.
//

#import "MJRefreshGifHeader.h"

@interface CCRefreshGifHeader : MJRefreshGifHeader

@end
