//
//  CCRefreshBackGifFooter.h
//  ask_dear商家
//
//  Created by King.Com on 16/6/21.
//  Copyright © 2016年 King.Com. All rights reserved.
//

#import "MJRefreshBackGifFooter.h"

@interface CCRefreshBackGifFooter : MJRefreshBackGifFooter

@end
