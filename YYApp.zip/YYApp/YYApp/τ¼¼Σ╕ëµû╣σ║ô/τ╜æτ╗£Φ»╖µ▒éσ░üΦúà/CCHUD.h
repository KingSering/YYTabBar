//
//  CCHUD.h
//  e65_ios
//
//  Created by xiezhaolin on 16/3/28.
//  Copyright © 2016年 King.Com. All rights reserved.
//

#import "MBProgressHUD.h"

@interface CCHUD : MBProgressHUD
- (void)showLoadingViewWithString:(NSString *)string;
@end
