//
//  CCHUD.m
//  e65_ios
//
//  Created by xiezhaolin on 16/3/28.
//  Copyright © 2016年 King.Com. All rights reserved.
//

#import "CCHUD.h"

@implementation CCHUD

- (void)showHDAlertWithString:(NSString *)message//黑色提示框 自动消失
{
    MBProgressHUD *progressHud;
    if (!progressHud) {
        progressHud = [[MBProgressHUD alloc] initWithView:self];
        [self addSubview:progressHud];
    }
    
    progressHud.mode = MBProgressHUDModeText;
    progressHud.label.text = message;
    [progressHud showAnimated:YES];
    
    [self performBlock:^{
        [progressHud hideAnimated:YES];
        [progressHud removeFromSuperview];
    } afterDelay:1.5];
}

- (void)performBlock:(void(^)())block afterDelay:(NSTimeInterval)delay {
    dispatch_time_t popTime = dispatch_time(DISPATCH_TIME_NOW, (int64_t)(delay * NSEC_PER_SEC));
    dispatch_after(popTime, dispatch_get_main_queue(), block);
}

- (void)showWithLabelDeterminate {
    MBProgressHUD *progressHud;
    if (!progressHud) {
        progressHud = [[MBProgressHUD alloc] initWithView:self];
        [self addSubview:progressHud];
    }
    
    progressHud.mode = MBProgressHUDModeDeterminate;
    progressHud.label.text = @"下载中";
    [progressHud showAnimated:YES];
}

- (void)myProgressTask {
    
}

- (void)showLoadingViewWithString:(NSString *)string {//显示加载等待界面  几秒后消失
    UIView *hud = [self viewWithTag:9955];
    if (!hud) {
        UIImageView *imgView = [[UIImageView alloc] initWithFrame:CGRectMake(WIDTH/2.0-50, HEIGHT/2.0-50, 70, 70)];
        MBProgressHUD *progressHud = [[MBProgressHUD alloc] initWithView:self];
        [self addSubview:progressHud];
        
        progressHud.mode = MBProgressHUDModeCustomView;
        progressHud.label.text = string;
        [progressHud setTag:9955];
        [progressHud showAnimated:YES];
//        progressHud.color = [UIColor clearColor];
        [UIView animateWithDuration:0.5 animations:^{
            
            imgView.image = [UIImage imageNamed:@"jiazai_one"];
            [imgView setAnimationImages:@[[UIImage imageNamed:@"jiazai_one"],
                                          [UIImage imageNamed:@"jiazai_two"],
                                          [UIImage imageNamed:@"jiazai_three"],
                                          [UIImage imageNamed:@"jiazai_four"],
                                          [UIImage imageNamed:@"jiazai_five"],
                                          [UIImage imageNamed:@"jiazai_six"],
                                          [UIImage imageNamed:@"jiazai_seven"],
                                          [UIImage imageNamed:@"jiazai_eight"]]];
            imgView.animationDuration = 1;
            //            imgView.animationRepeatCount = 1;
            [imgView startAnimating];
            progressHud.customView = imgView;
            
        }completion:^(BOOL finished) {
            [self performSelector:@selector(stopLoadingView) withObject:nil afterDelay:2];
        }];
    }
    
}

- (void)showLoadingView{ //开始加载  需要手动关闭;
    MBProgressHUD* progressHud = [[MBProgressHUD alloc] initWithView:self];
    [self addSubview:progressHud];
    [self bringSubviewToFront:progressHud];
    progressHud.mode = MBProgressHUDModeIndeterminate;
    [progressHud showAnimated:YES];
    [progressHud setTag:9955];
}

- (void)stopLoadingView{ //关闭加载;
    
    [[self viewWithTag:9955]removeFromSuperview];
}


/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

@end
