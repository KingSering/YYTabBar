//
//  CCNetWork.h
//  e65_ios
//
//  Created by xiezhaolin on 16/3/28.
//  Copyright © 2016年 King.Com. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "CCNetWork.h"

typedef void (^SuccessBlock) (id message);
typedef void (^FailBlock) (id message);

@interface NetWork : NSObject

+ (id)shareInstance;

#pragma mark========= POST 请求 ===========
/*****
 *原生post（返回的是data类型）
 *****/
- (void)httpPostWithURLAndHud:(NSString *)url
                        param:(NSDictionary *)parmas
                    superView:(UIView *)view
                 successBlock:(void(^)(id responseObject))successBlock
                    failBlock:(void(^)(id responseObject))failBlock;

/*******
 *返回的数据是json类型(post)
 ********/
- (void)postWithJson:(NSString *)url
               param:(NSDictionary *)parmas
           superView:(UIView *)view
        successBlock:(void(^)(id responseObject))successBlock
           failBlock:(void(^)(id responseObject))failBlock;

/********
 *post提交保存图片文件的
 ******/
- (void)postSaveFile:(NSString *)url
               param:(NSDictionary *)parmas data:(NSData *)data name:(NSString *)name filename:(NSString *)fileName mimeType:(NSString *)mimeType
           superView:(UIView *)view
        successBlock:(void(^)(id responseObject))successBlock
           failBlock:(void(^)(id responseObject))failBlock;


#pragma mark========= GET 请求 ===========

/*******
 *返回的数据是数组类型
 **********/
- (void)httpGetWithURL:(NSString *)url
                 param:(NSDictionary *)parmas
                 clazz:(__unsafe_unretained Class)clazz
             superView:(UIView *)view
          successBlock:(SuccessBlock)successBlock
             failBlock:(FailBlock)failBlock;

/*********
 *get方法 返回值是data类型
 *****/
- (void)getWithData:(NSString *)url
              param:(NSDictionary *)parmas
          superView:(UIView *)view
       successBlock:(void(^)(id responseObject))successBlock
          failBlock:(void(^)(id responseObject))failBlock;

/***********
 *原生get
 ***/
- (void)httpGetWithURLAndHud:(NSString *)url
                       param:(NSDictionary *)parmas
                   superView:(UIView *)view
                successBlock:(void(^)(id responseObject))successBlock
                   failBlock:(void(^)(id responseObject))failBlock;

@end
