//
//  CCNetWork.m
//  e65_ios
//
//  Created by xiezhaolin on 16/3/28.
//  Copyright © 2016年 King.Com. All rights reserved.
//

#import "CCNetWork.h"
#import "AFNetworking.h"
#import "CCHUD.h"

@implementation NetWork
{
    AFHTTPSessionManager * _manager;
//    CCHUD *_hud;
    NSDictionary * _message;
}
+ (id)shareInstance {
    static dispatch_once_t onceToken;
    static NetWork * connect = nil;
    dispatch_once(&onceToken, ^{
        // 重写构造函数 在该函数中完成AF manager对象初始化 在后续的网络请求中直接使用
        connect = [[NetWork alloc] init];
    });
    return connect;
}

#pragma mark========= POST 请求 ===========
/*****
 *原生post（返回的是data类型）
  NSString *result = [[NSString alloc] initWithData:responseObject encoding:NSUTF8StringEncoding];
 
 NSDictionary *dic = [NSJSONSerialization JSONObjectWithData:responseObject options:(NSJSONReadingMutableContainers) error:nil];
 NSArray *array = (NSArray *)dic;
 
 OrderSmBean*md=[OrderSmBean mj_objectWithKeyValues:responseObject];
 
 *****/
- (void)httpPostWithURLAndHud:(NSString *)url
                        param:(NSDictionary *)parmas
                    superView:(UIView *)view
                 successBlock:(void(^)(id responseObject))successBlock
                    failBlock:(void(^)(id responseObject))failBlock;
{
    CCHUD *hud;
    if (view) {
        hud = [CCHUD showHUDAddedTo:view animated:YES];
    }
    
     NSString *strUrl  = [url stringByAppendingString:[NSString stringWithFormat:@"%@",[Commen getMobilephoneUniqueLogo]]];
    
    NSLog(@"parmas##%@\n",parmas);
    NSLog(@"url##%@\n",url);
    NSLog(@"strUrl##%@\n",strUrl);
    
    
    AFHTTPSessionManager * manager = [AFHTTPSessionManager manager];
    
    
    manager.responseSerializer = [AFHTTPResponseSerializer serializer];
    
    manager.responseSerializer.acceptableContentTypes = [NSSet setWithObjects: @"application/json", @"text/plain", nil];
    
    // 2.设置非校验证书模式
    manager.securityPolicy = [AFSecurityPolicy policyWithPinningMode:AFSSLPinningModeNone];
    manager.securityPolicy.allowInvalidCertificates = YES;
    [manager.securityPolicy setValidatesDomainName:NO];
    
    
    [manager POST:strUrl parameters:parmas progress:^(NSProgress * _Nonnull uploadProgress) {
        
    } success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
        
        if (successBlock) {
            
            [hud hideAnimated:YES];
            
             
            NSLog(@"responseObject##:%@",responseObject);
            
            successBlock(responseObject);
            
        }
        
    } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
        
        if (failBlock) {
            failBlock(error);
        }
        hud.label.text = error.localizedDescription;
        [hud hideAnimated:YES afterDelay:2];
        
        NSLog(@"error##:%@\n",error.localizedDescription);
        
    }];
}
/*******
 *返回的数据是json类型(post)
 
 NSArray*aa=(NSArray*)responseObject;
 
 weakSelf.drawModel = [DrawPrizeModel mj_objectWithKeyValues:responseObject];
 
 ********/
- (void)postWithJson:(NSString *)url
               param:(NSDictionary *)parmas
           superView:(UIView *)view
        successBlock:(void(^)(id responseObject))successBlock
           failBlock:(void(^)(id responseObject))failBlock;
{
    
    NSString *strUrl  = [url stringByAppendingString:[NSString stringWithFormat:@"%@",[Commen getMobilephoneUniqueLogo]]];
    
    CCHUD *hud;
        if (view)
        {
            hud = [CCHUD showHUDAddedTo:view animated:YES];
        }
    NSLog(@"parmas##%@\n",parmas);
    NSLog(@"url##%@\n",url);
    NSLog(@"strUrl##%@\n",strUrl);
    
    AFHTTPSessionManager * manager = [AFHTTPSessionManager manager];
    
    [manager POST:strUrl parameters:parmas progress:^(NSProgress * _Nonnull uploadProgress) {
        
    } success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
        
        if (successBlock) {
            
            NSLog(@"responseObject##:%@",responseObject);
            
            [hud hideAnimated:YES];
            successBlock(responseObject);
        }
        
    } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
        
        if (failBlock) {
            failBlock(error);
        }
        
        NSLog(@"error##:%@\n",error.localizedDescription);
        
        hud.label.text = error.localizedDescription;
        [hud hideAnimated:YES afterDelay:2];
        
    }];
   
}

/********
 *post提交保存图片文件的
 ******/
- (void)postSaveFile:(NSString *)url
               param:(NSDictionary *)parmas data:(NSData *)data name:(NSString *)name filename:(NSString *)fileName mimeType:(NSString *)mimeType
           superView:(UIView *)view
        successBlock:(void(^)(id responseObject))successBlock
           failBlock:(void(^)(id responseObject))failBlock;
{
    NSString *strUrl  = [url stringByAppendingString:[NSString stringWithFormat:@"%@",[Commen getMobilephoneUniqueLogo]]];
    CCHUD *hud;
    if (view) {
        hud = [CCHUD showHUDAddedTo:view animated:YES];
    }
    AFHTTPSessionManager * manager = [AFHTTPSessionManager manager];
    manager.responseSerializer = [[AFCompoundResponseSerializer alloc] init];
    
    // 2.设置非校验证书模式
    manager.securityPolicy = [AFSecurityPolicy policyWithPinningMode:AFSSLPinningModeNone];
    manager.securityPolicy.allowInvalidCertificates = YES;
    [manager.securityPolicy setValidatesDomainName:NO];
    
    
    [manager POST:strUrl parameters:parmas constructingBodyWithBlock:^(id<AFMultipartFormData>  _Nonnull formData) {
        
        [formData appendPartWithFileData:data name:name fileName:fileName mimeType:mimeType];
        
    } progress:^(NSProgress * _Nonnull uploadProgress) {
        
        
        
    } success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
        
        if (successBlock) {
            [hud hideAnimated:YES];
            successBlock(responseObject);
        }
        
    } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
        
        if (failBlock) {
            failBlock(error);
        }
        hud.label.text = error.localizedDescription;
        [hud hideAnimated:YES afterDelay:2];
        
    }];
}




#pragma mark========= GET 请求 ===========

/*******
 *返回的数据是数组类型
 NSArray *arr = message;
 
 **********/
- (void)httpGetWithURL:(NSString *)url
                 param:(NSDictionary *)parmas
                 clazz:(__unsafe_unretained Class)clazz
             superView:(UIView *)view
          successBlock:(SuccessBlock)successBlock
             failBlock:(FailBlock)failBlock;
{
    NSString *strUrl  = [url stringByAppendingString:[NSString stringWithFormat:@"%@",[Commen getMobilephoneUniqueLogo]]];
    CCHUD *hud;
    if (view) {
        hud = [CCHUD showHUDAddedTo:view animated:YES];
    }
    AFHTTPSessionManager * manager = [AFHTTPSessionManager manager];
    manager.requestSerializer = [AFJSONRequestSerializer serializer];
    [manager.requestSerializer setTimeoutInterval:20];
    manager.responseSerializer = [AFJSONResponseSerializer serializer];
    
    // 2.设置非校验证书模式
    manager.securityPolicy = [AFSecurityPolicy policyWithPinningMode:AFSSLPinningModeNone];
    manager.securityPolicy.allowInvalidCertificates = YES;
    [manager.securityPolicy setValidatesDomainName:NO];
    
    [manager GET:strUrl parameters:parmas progress:^(NSProgress * _Nonnull downloadProgress) {
        
    } success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
        
        NSArray * resultArray = responseObject;
        if (successBlock) {
            NSMutableArray *array = [NSMutableArray array];
            [resultArray enumerateObjectsUsingBlock:^(id  _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
                NSDictionary *dic = (NSDictionary *)obj;
                id modelObj = [clazz mj_objectWithKeyValues:dic];
                [array addObject:modelObj];
            }];
            [hud hideAnimated:YES];
            successBlock(array);
        }
        
    } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
        
        if (failBlock) {
            failBlock(error);
        }
        hud.label.text = error.localizedDescription;
        [hud hideAnimated:YES afterDelay:2];
        
    }];
}

/*********
 *get方法 返回值是data类型
 
 NSString *resultStr = [[NSString alloc] initWithData:responseObject encoding:NSUTF8StringEncoding];
 
 *****/
- (void)getWithData:(NSString *)url
              param:(NSDictionary *)parmas
          superView:(UIView *)view
       successBlock:(void(^)(id responseObject))successBlock
          failBlock:(void(^)(id responseObject))failBlock;
{
    NSString *strUrl  = [url stringByAppendingString:[NSString stringWithFormat:@"%@",[Commen getMobilephoneUniqueLogo]]];
    CCHUD *hud;
    if (view) {
        hud = [CCHUD showHUDAddedTo:view animated:YES];
    }
    AFHTTPSessionManager * manager = [AFHTTPSessionManager manager];
    manager.responseSerializer = [AFHTTPResponseSerializer serializer];
    manager.responseSerializer.acceptableContentTypes = [NSSet setWithObjects: @"application/json", @"text/plain", nil];
    
    // 2.设置非校验证书模式
    manager.securityPolicy = [AFSecurityPolicy policyWithPinningMode:AFSSLPinningModeNone];
    manager.securityPolicy.allowInvalidCertificates = YES;
    [manager.securityPolicy setValidatesDomainName:NO];
    
    [manager GET:strUrl parameters:parmas progress:^(NSProgress * _Nonnull downloadProgress) {
        
    } success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
        
        if (successBlock) {
            [hud hideAnimated:YES];
            successBlock(responseObject);
        }
        
    } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
        
        if (failBlock) {
            failBlock(error);
        }
        hud.label.text = error.localizedDescription;
        [hud hideAnimated:YES afterDelay:2];
        
    }];

}

/***********
 *原生get
 
 NSArray *array = (NSArray *)responseObject;
 
 NSString *string = [[NSString alloc] initWithData:responseObject encoding:NSUTF8StringEncoding];
 
 weakSelf.beanModel = [PhoneElectionBeanModel mj_objectWithKeyValues:responseObject];
 ***/
- (void)httpGetWithURLAndHud:(NSString *)url
                       param:(NSDictionary *)parmas
                   superView:(UIView *)view
                successBlock:(void(^)(id responseObject))successBlock
                   failBlock:(void(^)(id responseObject))failBlock;
{
    NSString *strUrl  = [url stringByAppendingString:[NSString stringWithFormat:@"%@",[Commen getMobilephoneUniqueLogo]]];
    CCHUD *hud;
    if (view) {
        hud = [CCHUD showHUDAddedTo:view animated:YES];
    }
    AFHTTPSessionManager * manager = [AFHTTPSessionManager manager];
    manager.requestSerializer = [AFJSONRequestSerializer serializer];
    [manager.requestSerializer setTimeoutInterval:20];
    manager.responseSerializer = [AFJSONResponseSerializer serializer];
    
    // 2.设置非校验证书模式
    manager.securityPolicy = [AFSecurityPolicy policyWithPinningMode:AFSSLPinningModeNone];
    manager.securityPolicy.allowInvalidCertificates = YES;
    [manager.securityPolicy setValidatesDomainName:NO];
    
    [manager GET:strUrl parameters:parmas progress:^(NSProgress * _Nonnull downloadProgress) {
        
    } success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
        
        if (successBlock) {
            [hud hideAnimated:YES];
            successBlock(responseObject);
        }
        
    } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
        
        if (failBlock) {
            failBlock(error);
        }
        hud.label.text= error.localizedDescription;
        [hud hideAnimated:YES afterDelay:2];
        
    }];
}
@end
