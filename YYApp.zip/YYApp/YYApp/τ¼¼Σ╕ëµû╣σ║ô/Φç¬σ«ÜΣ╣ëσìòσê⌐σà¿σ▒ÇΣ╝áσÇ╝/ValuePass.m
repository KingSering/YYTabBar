//
//  ValuePass.m
//  askDeerExpress
//
//  Created by King.Com on 2019/3/29.
//  Copyright © 2019 King.Com. All rights reserved.
//

#import "ValuePass.h"

static ValuePass*instance = nil;
static dispatch_once_t onceToken;

@implementation ValuePass

/***
 *创建单例
 ***/
+(instancetype)shareValuePass;
{
    dispatch_once(&onceToken, ^{
        instance = [[self alloc]init];
    });
    return instance;
}
/**
 *销毁单例
 ***/
+(void)attempDealloc;
{
    onceToken = 0; // 只有置成0,GCD才会认为它从未执行过.它默认为0.这样才能保证下次再次调用shareInstance的时候,再次创建对象.
    instance = nil;
}
@end
