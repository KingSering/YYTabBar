//
//  ValuePass.h
//  askDeerExpress
//
//  Created by King.Com on 2019/3/29.
//  Copyright © 2019 King.Com. All rights reserved.
//

#import <Foundation/Foundation.h>



@interface ValuePass : NSObject
@property(nonatomic,assign) NSInteger newsCount_order ;
@property(nonatomic,assign) NSInteger newsCount_daigou ;

@property(nonatomic,assign) NSInteger selectedIndex ;
@property(nonatomic,assign) BOOL Loading ;//是否刷新加载
@property(nonatomic,assign) BOOL Loading_address ;//是否刷新地址

@property(nonatomic,assign) BOOL hiddenPop_youhuijuan ;//是否隐藏优惠卷弹出框
@property(nonatomic,assign) BOOL isUpApp ;//标记是否更新了app   

/***
 *创建单例
 ***/
+(instancetype)shareValuePass;
/**
 *销毁单例
 ***/
+(void)attempDealloc;
@end


