//
//  NSString+number.m
//  askDeerExpress
//
//  Created by King.Com on 2020/6/9.
//  Copyright © 2020 King.Com. All rights reserved.
//

#import "NSString+number.h"
 
@implementation NSString (number)
+ (BOOL)isNumber:(NSString *)string{
    
    //判断是不是纯数字
    [NSCharacterSet decimalDigitCharacterSet];
    if ([[string stringByTrimmingCharactersInSet: [NSCharacterSet decimalDigitCharacterSet]] trimming].length >0) {
        return NO;
    }else{
        NSLog(@"纯数字！");
    }
    
    return YES;
}

- (NSString *) trimming {
    
    return [self stringByTrimmingCharactersInSet: [NSCharacterSet whitespaceCharacterSet]];
}
@end
