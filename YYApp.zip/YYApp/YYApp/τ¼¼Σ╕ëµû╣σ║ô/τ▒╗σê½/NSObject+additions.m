//
//  NSObject+additions.m
//  askDeerExpress
//
//  Created by King.Com on 2019/3/11.
//  Copyright © 2019 King.Com. All rights reserved.
//

#import "NSObject+additions.h"

@implementation NSObject (additions)
+ (BOOL)dx_isNullOrNilWithObject:(id)object;
{
    if (object == nil || [object isEqual:[NSNull null]]) {
        return YES;
    } else if ([object isKindOfClass:[NSString class]]) {
        if ([object isEqualToString:@""]) {
            return YES;
        } else {
            return NO;
        }
    } else if ([object isKindOfClass:[NSNumber class]]) {
        if ([object isEqualToNumber:@0]) {
            return YES;
        } else {
            return NO;
        }
    }
    
    return NO;
}
@end
