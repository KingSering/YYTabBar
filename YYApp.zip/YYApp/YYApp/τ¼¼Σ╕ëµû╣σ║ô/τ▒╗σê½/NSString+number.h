//
//  NSString+number.h
//  askDeerExpress
//
//  Created by King.Com on 2020/6/9.
//  Copyright © 2020 King.Com. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSString (number)
+ (BOOL)isNumber:(NSString *)string;
@end

 
