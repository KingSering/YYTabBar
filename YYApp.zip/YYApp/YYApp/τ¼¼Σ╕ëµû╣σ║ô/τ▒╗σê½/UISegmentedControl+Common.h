//
//  UISegmentedControl+Common.h
//  askDeerExpress
//
//  Created by King.Com on 2020/2/19.
//  Copyright © 2020 King.Com. All rights reserved.
//
 #import <UIKit/UIKit.h>
 
 

@interface UISegmentedControl (Common)
- (void)ensureiOS13Style;
@end

 
