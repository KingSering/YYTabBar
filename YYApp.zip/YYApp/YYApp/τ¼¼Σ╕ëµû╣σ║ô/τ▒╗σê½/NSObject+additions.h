//
//  NSObject+additions.h
//  askDeerExpress
//
//  Created by King.Com on 2019/3/11.
//  Copyright © 2019 King.Com. All rights reserved.
//

#import <Foundation/Foundation.h>

 

@interface NSObject (additions)
/**
 *  判断对象是否为空
 *  PS：nil、NSNil、@""、@0 以上4种返回YES
 *
 *  @return YES 为空  NO 为实例对象
 */
+ (BOOL)dx_isNullOrNilWithObject:(id)object;
@end


