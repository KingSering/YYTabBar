//
//  UIButton+addSelectedArea.h
//  e65_ios
//
//  Created by King.Com on 2017/9/15.
//  Copyright © 2017年 King.Com. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIButton (addSelectedArea)

@end
