//
//  UITabBar+badge.h
//  askDeerExpress
//
//  Created by King.Com on 2019/4/10.
//  Copyright © 2019 King.Com. All rights reserved.
//

#import <UIKit/UIKit.h>

 

@interface UITabBar (badge)
/**
 tabbar显示小红点
 
 @param index 第几个控制器显示，从0开始算起
 @param tabbarNum tabbarcontroller一共多少个控制器
 */
- (void)showBadgeOnItmIndex:(int)index tabbarNum:(int)tabbarNum;
/**
 隐藏红点
 
 @param index 第几个控制器隐藏，从0开始算起
 */
-(void)hideBadgeOnItemIndex:(int)index;

@end

 
