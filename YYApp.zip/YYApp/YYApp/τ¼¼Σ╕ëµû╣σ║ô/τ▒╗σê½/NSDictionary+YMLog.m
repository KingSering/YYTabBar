//
//  NSDictionary+YMLog.m
//  e65_ios
//
//  Created by King.Com on 2017/8/4.
//  Copyright © 2017年 King.Com. All rights reserved.
//

#import "NSDictionary+YMLog.h"

@implementation NSDictionary (YMLog)
#if DEBUG
- (NSString *)descriptionWithLocale:(nullable id)locale{
    
    NSString *logString;
    
    @try {
        
        logString=[[NSString alloc] initWithData:[NSJSONSerialization dataWithJSONObject:self options:NSJSONWritingPrettyPrinted error:nil] encoding:NSUTF8StringEncoding];
        
    } @catch (NSException *exception) {
        
        NSString *reason = [NSString stringWithFormat:@"reason:%@",exception.reason];
        logString = [NSString stringWithFormat:@"转换失败:\n%@,\n转换终止,输出如下:\n%@",reason,self.description];
        
    } @finally {
        
    }
    return logString;
}
#endif

//作者：朱晓辉
//链接：http://www.jianshu.com/p/b6bb983e39da
//來源：简书
//著作权归作者所有。商业转载请联系作者获得授权，非商业转载请注明出处。
@end
