//
//  ScanVC.h
//  Cargo_ios
//
//  Created by King.Com on 2017/12/19.
//  Copyright © 2017年 King.Com. All rights reserved.
//

#import "BaseViewController.h"

typedef void(^ScanVCBlock)(NSString*string);



@interface ScanVC : BaseViewController
/** 是否直接获取扫描结果并返回 */
@property(nonatomic,assign) BOOL isBack ;

/** block */
@property(nonatomic,copy) ScanVCBlock scanVCBlock ;

 

@end
