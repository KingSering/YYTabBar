//
//  ScanVC.m
//  Cargo_ios
//
//  Created by King.Com on 2017/12/19.
//  Copyright © 2017年 King.Com. All rights reserved.
//

#import "ScanVC.h"



#import <AVFoundation/AVFoundation.h>



static const float padding = 60;// 扫描框 边距值


@interface ScanVC ()<AVCaptureMetadataOutputObjectsDelegate>
 
@property(nonatomic,strong)AVCaptureVideoPreviewLayer*qrVideoPreviewLayer; // 预览图层
@property(nonatomic,strong)AVCaptureSession*qrSession; // 会话
@property (nonatomic, strong) UIImageView *line;//交互线
@property (nonatomic, strong) NSTimer *lineTimer;//交互线控制



/**
 扫描获取的数据
 */
@property(nonatomic,strong) NSString * scanValue ;

@end

@implementation ScanVC

-(void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    [self.navigationController.navigationBar setHidden:YES];
    
    [self startQRCodeReader];
}
-(void)viewWillDisappear:(BOOL)animated
{
    [super viewWillDisappear:animated];
    [self.navigationController.navigationBar setHidden:NO];
    
}
-(void)dealloc
{
    if (_line)
    {
        _line=nil;
    }
    
    if (_qrVideoPreviewLayer)
    {
        _qrVideoPreviewLayer=nil;
    }
    
    if (_qrSession)
    {
        [_qrSession stopRunning];
        _qrSession=nil;
    }
  
    if (_lineTimer)
    {
        [_lineTimer invalidate];
        _lineTimer=nil;
    }
}

- (void)viewDidLoad {
    [super viewDidLoad];
    
    
    [self setScan];
    [self setOverlayPickerView];
    
     

     // Do any additional setup after loading the view.
}

-(void)setScan
{
    // 初始化捕捉设备AVCaptureDevice
    AVCaptureDevice*device=[AVCaptureDevice defaultDeviceWithMediaType:AVMediaTypeVideo];
    
    // 摄像头判断  输入设备
    NSError * error=nil;
    AVCaptureDeviceInput*input=[AVCaptureDeviceInput deviceInputWithDevice:device error:&error];
    if (error)
    {
        return;
    }
    
    //设置输出(Metadata元数据)
    AVCaptureMetadataOutput*output=[[AVCaptureMetadataOutput alloc]init];
    //设置输出的代理
    //使用主线程队列，相应比较同步，使用其他队列，相应不同步，容易让用户产生不好的体验
    [output setMetadataObjectsDelegate:self queue:dispatch_get_main_queue()];
    // 设置扫码范围
    //AVCaptureMetadataOutput 中的属性rectOfInterest 看起来是CGRect类型, 结果让你填写一个比例, 当你填写比例是你会发现还是有各种问题,  最后总结一下, 加入你的屏幕的frame 为  x , y,  w, h,  你要设置的矩形快的frame  为  x1, y1, w1, h1.   那么你的 rectOfInterest 应该设置为   CGRectMake(y1/y, x1/x, h1/h, w1/w),    不知道苹果的工程师怎么想的, 为什么坐标系搞这么复杂.直接设置实际大小 多好ne
    [output setRectOfInterest:CGRectMake(((HEIGHT-(WIDTH-padding*2))/2)/HEIGHT, ((WIDTH-(WIDTH-padding*2))/2)/WIDTH, (WIDTH-padding*2)/HEIGHT, (WIDTH-padding*2)/WIDTH)];
    
    //拍摄会话
    AVCaptureSession*session=[[AVCaptureSession alloc]init];
    
    // 读取质量，质量越高，可读取小尺寸的二维码
    
    if ([session canSetSessionPreset:AVCaptureSessionPresetHigh]) {
        
        [session setSessionPreset:AVCaptureSessionPresetHigh];
        
    } else if ([session canSetSessionPreset:AVCaptureSessionPresetPhoto]) {
        
        [session setSessionPreset:AVCaptureSessionPresetPhoto];
        
    } else  if ([session canSetSessionPreset:AVCaptureSessionPreset1920x1080])
    {
        [session setSessionPreset:AVCaptureSessionPreset1920x1080];
    }
    else if ([session canSetSessionPreset:AVCaptureSessionPreset1280x720])
    {
        [session setSessionPreset:AVCaptureSessionPreset1280x720];
    }
    else if ([session canSetSessionPreset:AVCaptureSessionPreset640x480]) {
        
        [session setSessionPreset:AVCaptureSessionPreset640x480];
        
    } else if ([session canSetSessionPreset:AVCaptureSessionPresetMedium]) {
        
        [session setSessionPreset:AVCaptureSessionPresetMedium];
        
    } else if ([session canSetSessionPreset:AVCaptureSessionPresetLow]) {
        
        [session setSessionPreset:AVCaptureSessionPresetLow];
        
    } else if ([session canSetSessionPreset:AVCaptureSessionPreset352x288]) {
        
        [session setSessionPreset:AVCaptureSessionPreset352x288];
        
    }
    else if ([session canSetSessionPreset:AVCaptureSessionPresetInputPriority]) {
        
        [session setSessionPreset:AVCaptureSessionPresetInputPriority];
        
    } else if ([session canSetSessionPreset:AVCaptureSessionPresetiFrame960x540]) {
        
        [session setSessionPreset:AVCaptureSessionPresetiFrame960x540];
        
    }
    else
    {
        [session setSessionPreset:AVCaptureSessionPresetPhoto];
    }
    
    
    if ([session canAddInput:input])
    {
        [session addInput:input];
    }
    
    if ([session canAddOutput:output])
    {
        [session addOutput:output];
    }
    
    //设置输出的格式
    //一定要先设置会话的输出为output之后，再指定输出的元数据类型(二维码和条形码)
    [output setMetadataObjectTypes:@[AVMetadataObjectTypeQRCode,AVMetadataObjectTypeEAN13Code,AVMetadataObjectTypeEAN8Code,AVMetadataObjectTypeCode128Code]];
    
    //设置预览图层 创建图层，摄像头捕捉到的画面都会在这个图层显示
    AVCaptureVideoPreviewLayer*preview=[AVCaptureVideoPreviewLayer layerWithSession:session];
     // 设置图层填充方式 //设置preview图层的属性
    [preview setVideoGravity:AVLayerVideoGravityResizeAspectFill];
    //设置preview图层的大小
    preview.frame=self.view.layer.bounds;
    
    //将图层添加到视图的图层
    [self.view.layer insertSublayer:preview atIndex:0];
    
    self.qrVideoPreviewLayer=preview;
    self.qrSession=session;

}
#pragma mark+++++设置预览图层中的扫描框++++
-(void)setOverlayPickerView
{
    //画中间的基准线 扫描线
    _line=[[UIImageView alloc]initWithFrame:CGRectMake(padding, (HEIGHT-(WIDTH-padding*2))/2, (WIDTH-padding*2), 10)];
    _line.image=[UIImage imageNamed:@"ff_QRCodeScanLine"];
    [self.view addSubview:_line];
    
    // 扫描框外面加蒙板
    //最上部view
    UIView*upView=[[UIView alloc]initWithFrame:CGRectMake(0, 0, WIDTH, (HEIGHT-(WIDTH-padding*2))/2)];
    upView.alpha=0.45;
    upView.backgroundColor=[UIColor blackColor];
    [self.view addSubview:upView];
    
    //左侧的view
    UIView*leftView=[[UIView alloc]initWithFrame:CGRectMake(0, (HEIGHT-(WIDTH-padding*2))/2, padding, (WIDTH-padding*2))];
    leftView.alpha=0.45;
    leftView.backgroundColor=[UIColor blackColor];
    [self.view addSubview:leftView];
    
     //右侧的view
    UIView*rightView=[[UIView alloc]initWithFrame:CGRectMake(CGRectGetMaxX(leftView.frame)+(WIDTH-padding*2), (HEIGHT-(WIDTH-padding*2))/2, padding, (WIDTH-padding*2))];
    rightView.alpha=0.45;
    rightView.backgroundColor=[UIColor blackColor];
    [self.view addSubview:rightView];
    
    //底部view
    UIView*bottomView=[[UIView alloc]initWithFrame:CGRectMake(0,CGRectGetMaxY(upView.frame)+(WIDTH-padding*2), WIDTH, (HEIGHT-(WIDTH-padding*2))/2)];
    bottomView.alpha=0.45;
    bottomView.backgroundColor=[UIColor blackColor];
    [self.view addSubview:bottomView];
    
    //四个边角 中间扫描框的四周
    
    UIImage*cornerImg=[UIImage imageNamed:@"ScanQR1"];
    //左上角
    UIImageView*left_top_img=[[UIImageView alloc]initWithFrame:CGRectMake(CGRectGetMaxX(leftView.frame)-cornerImg.size.width/2, CGRectGetMaxY(upView.frame)-cornerImg.size.height/2, cornerImg.size.width, cornerImg.size.height)];
    left_top_img.image=cornerImg;
    [self.view addSubview:left_top_img];
    
    
    cornerImg=[UIImage imageNamed:@"ScanQR2"];
    //右上角
    UIImageView*right_top_img=[[UIImageView alloc]initWithFrame:CGRectMake(WIDTH-CGRectGetMaxX(leftView.frame)-cornerImg.size.width/2, CGRectGetMaxY(upView.frame)-cornerImg.size.height/2, cornerImg.size.width, cornerImg.size.height)];
    right_top_img.image=cornerImg;
    [self.view addSubview:right_top_img];
    
    cornerImg=[UIImage imageNamed:@"ScanQR3"];
    //左下角
    UIImageView*left_down_img=[[UIImageView alloc]initWithFrame:CGRectMake(CGRectGetMaxX(leftView.frame)-cornerImg.size.width/2,HEIGHT- CGRectGetMaxY(upView.frame)-cornerImg.size.height/2, cornerImg.size.width, cornerImg.size.height)];
    left_down_img.image=cornerImg;
    [self.view addSubview:left_down_img];
    
    cornerImg=[UIImage imageNamed:@"ScanQR4"];
    //右下角
    UIImageView*right_down_img=[[UIImageView alloc]initWithFrame:CGRectMake(WIDTH-CGRectGetMaxX(leftView.frame)-cornerImg.size.width/2,HEIGHT- CGRectGetMaxY(upView.frame)-cornerImg.size.height/2, cornerImg.size.width, cornerImg.size.height)];
    right_down_img.image=cornerImg;
    [self.view addSubview:right_down_img];
    
    UILabel*tipLabel=[[UILabel alloc]initWithFrame:CGRectMake(40, 40+ CGRectGetMinY(bottomView.frame), WIDTH-40*2, 40)];
    tipLabel.text=LocalizedString(@"将条码放入扫描框内");
    tipLabel.textColor=[UIColor whiteColor];
    tipLabel.textAlignment=NSTextAlignmentCenter;
    tipLabel.numberOfLines=0;
    tipLabel.font=[UIFont systemFontOfSize:14];
    tipLabel.adjustsFontSizeToFitWidth=YES;
    tipLabel.backgroundColor=[UIColor grayColor];
    [self.view addSubview:tipLabel];
    
//    UILabel*tipLabel1=[[UILabel alloc]initWithFrame:CGRectMake(40, 20+ CGRectGetMaxY(tipLabel.frame), WIDTH-40*2, 40)];
//    tipLabel1.text=LocalizedString(@"手动输入");
//    tipLabel1.textColor=[UIColor whiteColor];
//    tipLabel1.textAlignment=NSTextAlignmentCenter;
//    tipLabel1.numberOfLines=0;
//    tipLabel1.font=[UIFont systemFontOfSize:14];
//    tipLabel1.adjustsFontSizeToFitWidth=YES;
//    tipLabel1.backgroundColor=MAINCOLOR;
//    UITapGestureRecognizer*tap=[[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(tap_action:)];
//    tipLabel1.userInteractionEnabled=YES;
//    [tipLabel1 addGestureRecognizer:tap];
//    [self.view addSubview:tipLabel1];
    
    
    
}
#pragma mark 交互事件
// 开始扫描
-(void)startQRCodeReader
{
    _lineTimer=[NSTimer scheduledTimerWithTimeInterval:1.0/20 target:self selector:@selector(lineFrameAnimation) userInfo:nil repeats:YES];
    //开始扫码
    [self.qrSession startRunning];

}
// 结束扫描
-(void)stopQrcodeReader
{
    if (_lineTimer)
    {
        [_lineTimer invalidate];
        _lineTimer=nil;
    }
    
    [self.qrSession stopRunning];
}
#pragma mark 上下滚动交互线
-(void)lineFrameAnimation
{
    __block CGRect frame=_line.frame;
    
    static BOOL flag =YES;
    
    if (flag)
    {
        frame.origin.y=(HEIGHT-(WIDTH-padding*2))/2 ;
        flag=NO;
        
        [UIView animateWithDuration:1/20 animations:^{
            
            frame.origin.y+=5;
            _line.frame=frame;
            
        }];
    }
    else
    {
        if (_line.frame.origin.y>=((HEIGHT-(WIDTH-padding*2))/2))
        {
            if (_line.frame.origin.y>=(((HEIGHT-(WIDTH-padding*2))/2)+(WIDTH-padding*2))-10.0)
            {
                frame.origin.y=(HEIGHT-(WIDTH-padding*2))/2 ;
                _line.frame=frame;
                flag=YES;
            }
            else
            {
                [UIView animateWithDuration:1/20 animations:^{
                    
                    frame.origin.y+=5;
                    _line.frame=frame;
                    
                }];
                
            }
        }
        else
        {
            flag=!flag;
        }
        
    }
    
}

#pragma mark ++++输出代理方法++++
//此方法是在识别到QRCode，并且完成转换
//如果QRCode的内容越大，转换需要的时间就越长
-(void)captureOutput:(AVCaptureOutput *)output didOutputMetadataObjects:(NSArray<__kindof AVMetadataObject *> *)metadataObjects fromConnection:(AVCaptureConnection *)connection
{
    //扫描结果
    if (metadataObjects.count>0)
    {
        [self stopQrcodeReader];
        
        AVMetadataMachineReadableCodeObject*obj=metadataObjects[0];
        NSLog(@"obj.stringValue==%@\n",obj.stringValue);
        if (NULLString(obj.stringValue))
        {
            //扫描失败
            
        }
        else
        {
            //存储扫描时获取的值
            self.scanValue=obj.stringValue;
            
            if (self.isBack)
            {
                if (self.scanVCBlock)
                {
                    self.scanVCBlock(obj.stringValue);
                }
                
                [self.navigationController popViewControllerAnimated:NO];
            }
            else
            {
            
        
            }
            
            
            
        }
    }
    
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
