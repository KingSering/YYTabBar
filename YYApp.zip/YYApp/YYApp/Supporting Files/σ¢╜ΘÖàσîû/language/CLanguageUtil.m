//
//  CLanguageUtil.m
//  eCarry
//
//  Created by whde on 16/1/6.
//  Copyright © 2016年 whde. All rights reserved.
//

#import "CLanguageUtil.h"
static NSBundle *bundle = nil;
@implementation CLanguageUtil
    
    // 获取Bundle
+(NSBundle *)bundle{
    if (bundle == nil) {
        NSString *userLanguage = [[NSUserDefaults standardUserDefaults] valueForKey:@"userLanguage"];
        if (userLanguage) {
            NSString *path = [[NSBundle mainBundle] pathForResource:userLanguage ofType:@"lproj"];
            bundle = [NSBundle bundleWithPath:path];
            return bundle;
        } else {
            bundle = [NSBundle mainBundle];
        }
    }
    return bundle;
}
    
    // 设置Bundle
+ (void)setBundle:(nullable NSString *)userLanguage
{
    if (userLanguage)
    {
        NSString *path = [[NSBundle mainBundle] pathForResource:userLanguage ofType:@"lproj"];
        bundle = [NSBundle bundleWithPath:path];
    } else
    {
        bundle = [NSBundle mainBundle];
    }
}
    
    // 获取当前语言
+ (Language)getCurrentLanguage
{
    NSString *language = [[NSUserDefaults standardUserDefaults] valueForKey:@"userLanguage"];
    if (language)
    {
#if DEBUG 
#endif
    }
    else
    {
        //        return Language_EN;
        NSArray *languages = [NSLocale preferredLanguages];
        language = [languages objectAtIndex:0];
#if DEBUG
#endif
    }
    if ([language rangeOfString:@"en"].location != NSNotFound)
    {
        return Language_EN;
    } else if ([language rangeOfString:@"Hans"].location != NSNotFound)
    {
        return Language_Hans;
    }else if ([language rangeOfString:@"MM"].location != NSNotFound)
    {
        return Language_Malaysia;
    }
    else
    {
        return Language_Default;
    }
}
    
    
// 设置语言
+ (void)setCurrentLanguage:(Language)language
{
    switch (language)
    {
        case Language_EN:
        [[NSUserDefaults standardUserDefaults] setValue:@"en" forKey:@"userLanguage"];
        [self setBundle:@"en"];
        break;
        case Language_Hans:
        [[NSUserDefaults standardUserDefaults] setValue:@"zh-Hans" forKey:@"userLanguage"];
        [self setBundle:@"zh-Hans"];
        break;
        case Language_Malaysia:
        [[NSUserDefaults standardUserDefaults] setValue:@"my-MM" forKey:@"userLanguage"];
        [self setBundle:@"my-MM"];
        break;
        case Language_Default:
        [[NSUserDefaults standardUserDefaults] setValue:@"my-MM" forKey:@"userLanguage"];
        [self setBundle:@"my-MM"];
        default:
        [[NSUserDefaults standardUserDefaults] setValue:@"en" forKey:@"userLanguage"];
        [self setBundle:@"en"];
        break;
    }
    [[NSUserDefaults standardUserDefaults] synchronize];
    [[NSNotificationCenter defaultCenter] postNotificationName:LANGUAGE_CHANGE_NOTIFICATION object:nil];
    
   
}
    
    // 获取xib国际化文件
+ (NSString *)localizedNibName:(NSString *)key
{
    switch ([self getCurrentLanguage])
    {
        case Language_Default:
        return key;
        break;
        case Language_EN:
        return [@"en.lproj/" stringByAppendingString:key];
        break;
        case Language_Hans:
        return [@"zh-Hans.lproj/" stringByAppendingString:key];
        break;
        case Language_Malaysia:
        return [@"my-MM.lproj/" stringByAppendingString:key];
        break;
        default:
        return [@"en.lproj/" stringByAppendingString:key];
        break;
    }
}
+(void)load
{
        // 交换MJ的国际化方法
        Method mjMethod = class_getClassMethod([NSBundle class],@selector(mj_localizedStringForKey:value:));
        Method myMethod = class_getClassMethod(self, @selector(hook_mj_localizedStringForKey:value:));
        method_exchangeImplementations(mjMethod, myMethod);
}
    
    /// hook刷新控件的提示文字
+(NSString *)hook_mj_localizedStringForKey:(NSString *)key value:(NSString *)value 
{
    static NSBundle *bundle = nil;

    NSString *language = [[NSUserDefaults standardUserDefaults] valueForKey:@"userLanguage"];

//    if (!language)
//    {
//      language = [[NSUserDefaults standardUserDefaults] valueForKey:@"userLanguage"];
//    }
    
//    NSString *language = [[NSUserDefaults standardUserDefaults] valueForKey:@"userLanguage"];

//    if (bundle == nil)
//    {


//        if (language)
//        {
            bundle = [NSBundle bundleWithPath:[[NSBundle mj_refreshBundle] pathForResource:language  ofType:@"lproj"]];
//        }
//        else
//        {
//            bundle=[NSBundle bundleWithPath:[[NSBundle mj_refreshBundle] pathForResource:@"en" ofType:@"lproj"]];
//        }
        
    //}
//    NSLog(@"language=--%@",[[NSUserDefaults standardUserDefaults] valueForKey:@"userLanguage"]);
//
//    NSLog(@"language++=%@",language);
    
        value = [bundle localizedStringForKey:key value:value table:nil];
        return [[NSBundle mainBundle] localizedStringForKey:key value:value table:@"Localizable"];
}

    @end
// 版权属于原作者
// http://code4app.com (cn) http://code4app.net (en)
// 发布代码于最专业的源码分享网站: Code4App.com
