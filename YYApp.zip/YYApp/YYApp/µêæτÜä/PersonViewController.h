//
//  PersonViewController.h
//  YYApp
//
//  Created by King.Com on 2018/10/9.
//  Copyright © 2018年 King.Com. All rights reserved.
//

#import "BaseViewController.h"

@interface PersonViewController : BaseViewController

@end
