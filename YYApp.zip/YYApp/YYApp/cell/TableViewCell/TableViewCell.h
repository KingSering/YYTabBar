//
//  TableViewCell.h
//  CargoSalesman
//
//  Created by King.Com on 2018/6/16.
//  Copyright © 2018年 King.Com. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TableViewCell : UITableViewCell

#pragma mark=========cell0===========
@property (weak, nonatomic) IBOutlet UILabel *cell0_titleLb;
@property (weak, nonatomic) IBOutlet UITextField *cell0_textField;

 






@end
