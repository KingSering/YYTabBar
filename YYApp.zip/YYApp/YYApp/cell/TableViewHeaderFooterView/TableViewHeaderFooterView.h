//
//  TableViewHeaderFooterView.h
//  askDeerExpress
//
//  Created by King.Com on 2019/2/23.
//  Copyright © 2019 King.Com. All rights reserved.
//

#import <UIKit/UIKit.h>

 
@interface TableViewHeaderFooterView : UITableViewHeaderFooterView

#pragma mark+++++ headerFooter0 +++++++

@property (weak, nonatomic) IBOutlet UILabel *headerFooter0_leftTopLb;
@property (weak, nonatomic) IBOutlet UILabel *headerFooter0_rightTopLb;
@property (weak, nonatomic) IBOutlet UILabel *headerFooter0_bottomLeftLb;
@property (weak, nonatomic) IBOutlet UILabel *headerFooter0_bottomCenterLb;
@property (weak, nonatomic) IBOutlet UILabel *headerFooter0_bottomRightLb;

#pragma mark+++++ headerFooter1 +++++++

 

 


@end

 
