//
//  TableViewHeaderFooterView.m
//  askDeerExpress
//
//  Created by King.Com on 2019/2/23.
//  Copyright © 2019 King.Com. All rights reserved.
//

#import "TableViewHeaderFooterView.h"
 

@implementation TableViewHeaderFooterView

-(void)updateConstraints
{
    [super updateConstraints];
    
    
    
}
 
/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

@end
