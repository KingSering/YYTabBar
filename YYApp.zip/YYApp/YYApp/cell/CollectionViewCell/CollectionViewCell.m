//
//  CollectionViewCell.m
//  CargoSalesman
//
//  Created by King.Com on 2018/6/14.
//  Copyright © 2018年 King.Com. All rights reserved.
//

#import "CollectionViewCell.h"

@implementation CollectionViewCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

@end
