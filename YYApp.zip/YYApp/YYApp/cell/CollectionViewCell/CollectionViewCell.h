//
//  CollectionViewCell.h
//  CargoSalesman
//
//  Created by King.Com on 2018/6/14.
//  Copyright © 2018年 King.Com. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CollectionViewCell : UICollectionViewCell

#pragma mark=========cell0===========
@property (weak, nonatomic) IBOutlet UIImageView *cell0_img;
@property (weak, nonatomic) IBOutlet UILabel *cell0_textLb;


#pragma mark=========cell1===========
@property (weak, nonatomic) IBOutlet UILabel *cell1_textLb;



@end
