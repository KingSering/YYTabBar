//
//  MyUITabBar.h
//  YYApp
//
//  Created by King on 2020/9/26.
//  Copyright © 2020 King.Com. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN
@protocol RoundButtonDelegate <NSObject>

-(void)RoundButtonClicked;

@end
@interface MyUITabBar : UITabBar 
@property(nonatomic,weak)id <RoundButtonDelegate>myDelegate; 
@property(nonatomic,strong)UIButton*roundButton;

@end

NS_ASSUME_NONNULL_END
