//
//  MyUITabBar.m
//  YYApp
//
//  Created by King on 2020/9/26.
//  Copyright © 2020 King.Com. All rights reserved.
//

#import "MyUITabBar.h"

@implementation MyUITabBar 

 
//懒加载
-(UIButton*)roundButton
{
    if (!_roundButton)
    {
        _roundButton=[[UIButton alloc]init];
    }
    return _roundButton;
}
-(void)roundButtonClicked
{
    if ([self.myDelegate respondsToSelector:@selector(RoundButtonClicked)])
    {
        [self.myDelegate RoundButtonClicked];
    }
}
 -(void)layoutSubviews
{
    [super layoutSubviews];
    
     self.roundButton.backgroundColor=[UIColor whiteColor];
    [self.roundButton setBackgroundImage:[UIImage imageNamed:@"yuanqubao.png"] forState:UIControlStateNormal];
    [self.roundButton addTarget:self action:@selector(roundButtonClicked) forControlEvents:UIControlEventTouchUpInside];
    [self addSubview:self.roundButton];
    
    int centerx = self.bounds.size.width*0.5;
    int centery = self.bounds.size.height*0.5;
    self.roundButton.frame=CGRectMake(centerx-30, centery-50, 60, 60);
    self.roundButton.layer.cornerRadius=30;
    self.roundButton.clipsToBounds=YES;
    
    Class class = NSClassFromString(@"UITabBarButton");
    int index = 0;
    int tabWidth = self.bounds.size.width/3.0;
    for (UIView*view in self.subviews)
    {
        //找到UITabBarButton 类型的子控件
        if ([view isKindOfClass:class])
        {
            CGRect rect = view.frame;
            rect.origin.x = index*tabWidth;
            rect.size.width = tabWidth;
            view.frame = rect;
            index++;
            //留出位置放置中间凸出按钮
            if (index==1) {
                index++;
            }
        }
    }
}
//响应触摸事件，如果触摸位置位于圆形按钮控件上，则由圆形按钮处理触摸消息
- (UIView *)hitTest:(CGPoint)point withEvent:(UIEvent *)event{
    //判断tabbar是否隐藏
    if (self.hidden == NO) {
        if ([self touchPointInsideCircle:self.roundButton.center radius:30 targetPoint:point]) {
            //如果位于圆形按钮上，则由圆形按钮处理触摸消息
            return self.roundButton;
        }
        else{
            //否则系统默认处理
            return [super hitTest:point withEvent:event];
        }
    }
    return [super hitTest:point withEvent:event];
}
- (BOOL)touchPointInsideCircle:(CGPoint)center radius:(CGFloat)radius targetPoint:(CGPoint)point
{
    CGFloat dist = sqrtf((point.x - center.x) * (point.x - center.x) +
                         (point.y - center.y) * (point.y - center.y));
    return (dist <= radius);
}
/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

@end
