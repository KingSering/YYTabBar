//
//  UIBarButtonItem+Extension.m
//  
//
//  Created by apple on 14-10-7.
//  Copyright (c) 2014年 heima. All rights reserved.
//

#import "UIBarButtonItem+Extension.h"
#import "UIView+Extension.h"

@implementation UIBarButtonItem (Extension)

//iOS上直接缩小UIImageView的大小会产生锯齿,可以先将其缩放后再使用.
+ (UIImage *)scaleToSize:(UIImage *)img size:(CGSize)size
{
    UIGraphicsBeginImageContextWithOptions(size, NO, 0.0);
    [img drawInRect:CGRectMake(0, 0, size.width, size.height)];
    UIImage* scaledImage = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    return scaledImage;
}

/**
 *  创建一个item
 *  
 *  @param target    点击item后调用哪个对象的方法
 *  @param action    点击item后调用target的哪个方法
 *  @param image     图片
 *  @param highImage 高亮的图片
 *
 *  @return 创建完的item
 */
+ (UIBarButtonItem *)itemWithTarget:(id)target action:(SEL)action image:(NSString *)image highImage:(NSString *)highImage
{
    UIButton *btn = [UIButton buttonWithType:UIButtonTypeCustom];
    [btn addTarget:target action:action forControlEvents:UIControlEventTouchUpInside];
    // 设置图片
    UIImage*im1 = [self scaleToSize:[UIImage imageNamed:image] size:CGSizeMake(30, 30)];
    [btn setBackgroundImage:[im1 imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal] forState:UIControlStateNormal];
    
    UIImage*im2 = [self scaleToSize:[UIImage imageNamed:highImage] size:CGSizeMake(30, 30)];
    [btn setBackgroundImage:[im2 imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal] forState:UIControlStateHighlighted];
    // 设置尺寸
    //btn.size  = btn.currentBackgroundImage.size;
 
    return [[UIBarButtonItem alloc] initWithCustomView:btn];
}

+ (UIBarButtonItem *)itemWithTarget:(id)target action:(SEL)action title:(NSString *)title
{
    UIButton *btn = [UIButton buttonWithType:UIButtonTypeCustom];
    [btn addTarget:target action:action forControlEvents:UIControlEventTouchUpInside];
    // 设置图片
//    [btn setBackgroundImage:[UIImage imageNamed:nil] forState:UIControlStateNormal];
    btn.titleLabel.text = title;
    btn.titleLabel.textColor = [UIColor whiteColor];
    btn.backgroundColor = [UIColor clearColor];
    // 设置尺寸
//    btn.size = CGSizeMake(50, 20);
        btn.width = 10;
        btn.height = 10;
    
//        btn.size = CGSizeMake(43, 43);
    btn.size = CGSizeMake(25, 25);

    return [[UIBarButtonItem alloc] initWithCustomView:btn];
}
@end
