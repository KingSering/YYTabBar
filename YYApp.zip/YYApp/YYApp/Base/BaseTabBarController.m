//
//  BaseTabBarController.m
//  YYApp
//
//  Created by King.Com on 2018/10/9.
//  Copyright © 2018年 King.Com. All rights reserved.
//

#import "BaseTabBarController.h"
#import "MyUITabBar.h"
#import "ViewController.h"

@interface BaseTabBarController ()<RoundButtonDelegate>

@end

@implementation BaseTabBarController


- (void)viewDidLoad {
    [super viewDidLoad];
   
    
    
    
    
    [self setTabBarName];

    ViewController*vc=[[ViewController alloc]init];
    BaseNavigationController*navi=[[BaseNavigationController alloc]initWithRootViewController:vc];
    [self addChildViewController:navi];
    
    
    MyUITabBar*tabbar = [[MyUITabBar alloc]init];
    tabbar.myDelegate=self;
    //修改系统的Tabbar，使用我们自定义的Tabbar
        [self setValue:tabbar forKeyPath:@"tabBar"];
    
    // Do any additional setup after loading the view.
}
-(void)RoundButtonClicked
{
//    ViewController*vc=[[ViewController alloc]init];
//    vc.view.backgroundColor=[UIColor yellowColor];
//    BaseNavigationController*navi =[[BaseNavigationController alloc] initWithRootViewController:vc];
//    [self presentViewController:navi animated:YES completion:nil];
    [self viewControllers][0].tabBarController.selectedIndex = 2;
}
#pragma mark - 创建tabBar
- (void)setTabBarName
{
    //主页
    HomeViewController *vc1 = [[HomeViewController alloc] init];
    BaseNavigationController*nav1=(BaseNavigationController*)  [self addChildVc:vc1 title:LocalizedString(@"首页") image:@"shouye_gray" selectedImage:@"shouye_cheng+1"];
    
    //我的
    PersonViewController *vc2 = [[PersonViewController alloc] initWithNibName:@"PersonViewController" bundle:[NSBundle mainBundle]];
    BaseNavigationController*nav2=(BaseNavigationController*)   [self addChildVc:vc2 title:LocalizedString(@"我的") image:@"my_gray" selectedImage:@"my_cheng+1"];
    
    NSArray*vsArr = @[nav1,nav2];
    for (BaseNavigationController*vv in vsArr)
    {
        [self addChildViewController:vv];
    }
}
/**
 *  添加一个子控制器
 *
 *  @param childVc       子控制器
 *  @param title         标题
 *  @param image         图片
 *  @param selectedImage 选中的图片
 */
- (id)addChildVc:(UIViewController *)childVc title:(NSString *)title image:(NSString *)image selectedImage:(NSString *)selectedImage
{
     
    UIImage*normalImage = [[self scaleToSize:[UIImage imageNamed:image] size:CGSizeMake(30, 30)] imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal];
    
    UIImage*select_img= [ [self scaleToSize:[UIImage imageNamed:selectedImage] size:CGSizeMake(30, 30)] imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal];
    
    childVc.tabBarItem.image = normalImage;
    childVc.tabBarItem.selectedImage =select_img;
    // 设置子控制器的文字
    childVc.tabBarItem.title = title; // 设置tabbar的文字
    
    // 设置文字的样式
    NSMutableDictionary *textAttrs = [NSMutableDictionary dictionary];
    textAttrs[NSForegroundColorAttributeName] = [UIColor grayColor];

    NSMutableDictionary *selectTextAttrs = [NSMutableDictionary dictionary];
    //RGBA(255, 157, 38, 1)
    selectTextAttrs[NSForegroundColorAttributeName] = MAINCOLOR;
    [childVc.tabBarItem setTitleTextAttributes:textAttrs forState:UIControlStateNormal];
    [childVc.tabBarItem setTitleTextAttributes:selectTextAttrs forState:UIControlStateSelected];
    
     
    // 先给外面传进来的小控制器 包装 一个导航控制器
    BaseNavigationController *nav = [[BaseNavigationController alloc] initWithRootViewController:childVc];
  
    return nav;
    
    
    
}
//iOS上直接缩小UIImageView的大小会产生锯齿,可以先将其缩放后再使用.
- (UIImage *)scaleToSize:(UIImage *)img size:(CGSize)size
{
    UIGraphicsBeginImageContextWithOptions(size, NO, 0.0);
    [img drawInRect:CGRectMake(0, 0, size.width, size.height)];
    UIImage* scaledImage = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    return scaledImage;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
