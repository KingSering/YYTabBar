//
//  BaseViewController.m
//  YYApp
//
//  Created by King.Com on 2018/10/9.
//  Copyright © 2018年 King.Com. All rights reserved.
//

#import "BaseViewController.h"
#import "UIBarButtonItem+Extension.h"

@interface BaseViewController ()

@end

@implementation BaseViewController
- (void)viewSafeAreaInsetsDidChange {
    [super viewSafeAreaInsetsDidChange];
    
    NSLog(@"viewSafeAreaInsetsDidChange-%@",NSStringFromUIEdgeInsets(self.view.safeAreaInsets));
    
    [self updateOrientation];
}
/**
 更新屏幕safearea frame
 */
- (void)updateOrientation {
    if (@available(iOS 11.0, *)) {
        
        ////iOS 11.0还有一个属性additionalSafeAreaInsets，可以用来扩展安全区域的大小，
//        self.additionalSafeAreaInsets = UIEdgeInsetsMake(50, 50, 50, 50);
//        NSLog(@"additionalSafeAreaInsets-%@",NSStringFromUIEdgeInsets(self.additionalSafeAreaInsets));
//        NSLog(@"safeAreaInsets-%@",NSStringFromUIEdgeInsets(self.view.safeAreaInsets));
        
        
        
        CGRect frame = self.view.frame;
        frame.origin.x = self.view.safeAreaInsets.left;
        frame.size.width = self.view.frame.size.width - self.view.safeAreaInsets.left - self.view.safeAreaInsets.right;
        frame.size.height = self.view.frame.size.height - self.view.safeAreaInsets.bottom;
        self.view.frame = frame;
    } else {
        // Fallback on earlier versions
    }
}
- (void)viewDidLoad {
    [super viewDidLoad];
    
    [self.navigationController.navigationBar setBarTintColor:MAINCOLOR];
    
    // Do any additional setup after loading the view.
}
#pragma mark++++设置导航栏的标题/颜色/字体大小/背景颜色++++
-(void)setNavigationTitle:(NSString*)title  color:(UIColor*)color  font :(UIFont*)font backColor:(UIColor*)  backColor showLeftBtn:(BOOL)showLeftBtn;
{
    [self.navigationController.navigationBar setHidden:NO];
    
    if (title)
    {
        UILabel*titleLb=[[UILabel alloc]initWithFrame:CGRectMake(0, 0, 200, 30)];
        titleLb.text=title;
        if(font)
        {
            titleLb.font=font;
        }
        else
        {
            titleLb.font=[UIFont systemFontOfSize:17];
        }
        
        titleLb.textAlignment=NSTextAlignmentCenter;
        if (color)
        {
            titleLb.textColor=color;
        }
        else
        {
            titleLb.textColor=[UIColor whiteColor];
        }
        self.navigationItem.titleView=titleLb;
    }
    
    if (backColor)
    {
        [self.navigationController.navigationBar setBarTintColor:backColor];
    }
    else
    {
        [self.navigationController.navigationBar setBarTintColor:MAINCOLOR];
    }
    
    if (showLeftBtn)
    {
        // 设置左边的返回按钮
        self.navigationItem.leftBarButtonItem = [UIBarButtonItem itemWithTarget:self action:@selector(back) image:@"iconfont-fanhui" highImage:@"iconfont-fanhui"];
    }
    
}
- (void)back {
   
    [self.navigationController popViewControllerAnimated:NO];
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
