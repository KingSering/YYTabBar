//
//  BaseViewController.h
//  YYApp
//
//  Created by King.Com on 2018/10/9.
//  Copyright © 2018年 King.Com. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface BaseViewController : UIViewController
#pragma mark++++设置导航栏的标题/颜色/字体大小/背景颜色++++
-(void)setNavigationTitle:(NSString*)title  color:(UIColor*)color  font :(UIFont*)font backColor:(UIColor*)  backColor showLeftBtn:(BOOL)showLeftBtn;
@end
