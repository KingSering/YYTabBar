//
//  BaseModel.m
//  e65_ios
//
//  Created by King.Com on 16/3/28.
//  Copyright © 2016年 King.Com. All rights reserved.
//

#import "BaseModel.h"

@implementation BaseModel

- (NSString *)description
{
    return [self mj_keyValues].description;
}
//方法：将model文件中定义的字段名转化为与请求数据中相同的，使两者的内部相同，只是名称不同
+ (NSDictionary *)replacedKeyFromPropertyName
{
    return @{@"Description":@"description"};
}

@end
